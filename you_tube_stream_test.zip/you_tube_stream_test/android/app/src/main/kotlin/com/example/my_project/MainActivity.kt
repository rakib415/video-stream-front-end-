package com.mycompany.youtubestreamtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
